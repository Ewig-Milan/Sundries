/*
Things to notice:
1. do not calculate useless values
2. do not use similar names
 
Things to check:
1. submit the correct file
2. time (it is log^2 or log)
3. memory
4. prove your naive thoughts 
5. long long
6. corner case like n=0,1,inf or n=m
7. check if there is a mistake in the ds or other tools you use
8. fileio in some oi-contest

9. module on time 
10. the number of a same divisor in a math problem
11. multi-information and queries for dp and ds problems
*/
#include<bits/stdc++.h>
using namespace std;
#define int long long
#define fi first
#define se second
#define pii pair<long long,long long>
#define mp make_pair
#define pb push_back
const int mod=998244353;
const int inf=0x3f3f3f3f;
const int INF=1e18;
int n,A[100005],B[100005];
int ord[100005];
bool cmp(int x,int y)
{
	return B[x]>B[y];
}
vector <pii > g[100005];
struct LCA
{
	int dep[200005],dfn[200005],times;
	int dist[200005];
	int st[20][400005],Lg[400005];
	void dfs(int u,int fa)
	{
		dfn[u]=++times,st[0][times]=u;
		for(int i=0;i<g[u].size();i++)
		{
			int v=g[u][i].fi;
			if(v==fa) continue;
			dep[v]=dep[u]+1,dist[v]=dist[u]+1LL*g[u][i].se,dfs(v,u);
			st[0][++times]=u;
		}
	}
	int mindep(int x,int y)
	{
		if(dep[x]<dep[y]) return x;
		return y;
	}
	void build()
	{
		times=0,dep[1]=dist[1]=0;
		dfs(1,-1);
		Lg[1]=0,Lg[2]=1;
		for(int i=3;i<=times;i++) Lg[i]=Lg[i/2]+1;
		for(int k=1;k<20;k++) for(int i=1;i+(1<<k)-1<=times;i++) 
			st[k][i]=mindep(st[k-1][i],st[k-1][i+(1<<(k-1))]);
	}
	int getlca(int u,int v)
	{
		u=dfn[u],v=dfn[v];
		if(u>v) swap(u,v);
		int s=Lg[v-u+1];
		return mindep(st[s][u],st[s][v-(1<<s)+1]);
	}
	int getdis(int u,int v)
	{
		int l=getlca(u,v);
		return dist[u]+dist[v]-2LL*dist[l];	
	}
}Lca;
int sz[100005],maxsz[100005],rt=0,tot;
vector <int> h[100005];
int vis[100005],par[100005];
void dfs0(int u,int fa)
{
	sz[u]=1;
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i].fi;
		if(vis[v]||v==fa) continue;
		dfs0(v,u),sz[u]+=sz[v];
	}
}
void dfs1(int u,int fa)
{
	maxsz[u]=0;
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i].fi;
		if(vis[v]||v==fa) continue;
		maxsz[u]=max(maxsz[u],sz[v]),dfs1(v,u);
	}
	maxsz[u]=max(maxsz[u],tot-sz[u]);
	if(maxsz[u]<maxsz[rt]) rt=u;
}
void calc(int u)
{
	vis[u]=1;
	vector <pii > ss;
	ss.clear();
	dfs0(u,-1);
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i].fi;
		if(vis[v]) continue;
		ss.pb(mp(v,sz[v]));
	}
	for(int i=0;i<ss.size();i++)
	{
		rt=0,tot=ss[i].se;
		dfs1(ss[i].fi,-1);
		par[rt]=u;
		calc(rt);
	}
}
int dp[100005];
vector <pii > stk[100005];
vector <double > pnt[100005];
double get(pii x,pii y)
{
	if(x.fi==y.fi) return (x.se>y.se?-1e18:1e18);
	return 1.0*(y.se-x.se)/(x.fi-y.fi);
}
void ins(int id,pii li)
{
	li.fi*=-1,li.se*=-1;
	if(!stk[id].size()) stk[id].pb(li),pnt[id].pb(-1e18);
	else
	{
		while(stk[id].size()>1&&get(li,stk[id].back())<pnt[id].back()) stk[id].pop_back(),pnt[id].pop_back();
		pnt[id].pb(get(li,stk[id].back())),stk[id].pb(li);
	}
}
int query(int x,int y)
{
	if(!stk[x].size()) return INF;
	int pos=upper_bound(pnt[x].begin(),pnt[x].end(),(double)(y))-pnt[x].begin()-1;
	int res=y*stk[x][pos].fi+stk[x][pos].se;
	return -res;
}
void trans(int id)
{
	dp[id]=min(dp[id],A[1]+Lca.getdis(1,id)*B[1]);
	int u=id;
	while(u) dp[id]=min(dp[id],query(u,Lca.getdis(id,u))),u=par[u];
	u=id;
	while(u) ins(u,mp(B[id],dp[id]+Lca.getdis(id,u)*B[id]+A[id])),u=par[u];
}
void trans2(int id)
{
	dp[id]=min(dp[id],A[1]+Lca.getdis(1,id)*B[1]);
	int u=id;
	while(u) dp[id]=min(dp[id],query(u,Lca.getdis(id,u))),u=par[u];
}
vector <int> travel(vector <int> _A,vector <signed> _B,vector <signed> _U,vector <signed> _V,vector <signed> _W)
{
	n=_A.size();
	for(int i=1;i<=n;i++) A[i]=_A[i-1],B[i]=_B[i-1];
	for(int i=0;i<_U.size();i++)
	{
		int u=_U[i],v=_V[i],w=_W[i];
		u++,v++;
		g[u].pb(mp(v,w)),g[v].pb(mp(u,w));
	}
	Lca.build();
	maxsz[0]=tot=n;
	dfs0(1,-1),dfs1(1,-1),calc(rt);
	memset(dp,0x3f,sizeof(dp));
	dp[1]=0;
	for(int i=1;i<=n;i++) ord[i]=i;
	sort(ord+1,ord+1+n,cmp);
	for(int i=1;i<=n;i++) if(ord[i]!=1) trans(ord[i]);
	for(int i=1;i<=n;i++) if(ord[i]!=1) trans2(ord[i]);
	vector <int> ret;
	for(int i=2;i<=n;i++) ret.pb(dp[i]);
	return ret;
}
void solve()
{
	int _n;
	cin>>_n;
	vector <int> _a;
	vector <signed> _b,_u,_v,_w;
	for(int i=1;i<=_n;i++)
	{
		int x;
		cin>>x;
		_a.pb(x);
	}
	for(int i=1;i<=_n;i++)
	{
		signed x;
		cin>>x;
		_b.pb(x);
	}
	for(int i=1;i<_n;i++)
	{
		signed u,v,w;
		cin>>u>>v>>w;
		_u.pb(u),_v.pb(v),_w.pb(w);
	}
	vector <int> tmp=travel(_a,_b,_u,_v,_w);
	for(int i=0;i<tmp.size();i++) cout<<tmp[i]<<"\n";
}
signed main()
{
//	ios::sync_with_stdio(0);
//	cin.tie(0);
	int _=1;
//	cin>>_;
	while(_--) solve();
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
#define int long long
#define fi first
#define se second
#define pii pair<long long,long long>
#define mp make_pair
#define pb push_back
int n;
int a[505][505];
void solve()
{
	freopen("5-3.in","r",stdin);
	freopen("5-3.ans","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) cin>>a[i][j];
	int r1=0,r2=0;
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) r1=max(r1,abs(a[i][j]-a[n][1])),r2=max(r2,abs(a[i][j]-a[1][n]));
	cout<<min(r1,r2)<<"\n";
}
signed main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	int _=1;
//	cin>>_;
	while(_--) solve();
	return 0;
}

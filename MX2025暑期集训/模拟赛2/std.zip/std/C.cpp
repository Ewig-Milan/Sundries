/*
Things to notice:
1. do not calculate useless values
2. do not use similar names
 
Things to check:
1. submit the correct file
2. time (it is log^2 or log)
3. memory
4. prove your naive thoughts 
5. long long
6. corner case like n=0,1,inf or n=m
7. check if there is a mistake in the ds or other tools you use
8. fileio in some oi-contest

9. module on time 
10. the number of a same divisor in a math problem
11. multi-information and queries for dp and ds problems
*/
#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pii pair<int,int>
#define mp make_pair
#define pb push_back
const int mod=998244353;
const int inf=0x3f3f3f3f;
int n,m;
int a[6][100005],pos[6][100006],minn[6],minn2[6];
int dp[18][100005][6];
void solve()
{
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++) for(int j=1;j<=n;j++) scanf("%d",&a[i][j]),pos[i][a[i][j]]=j;
	memset(dp,0x3f,sizeof(dp));
	for(int i=1;i<=m;i++) 
	{
		memset(minn,0x3f,sizeof(minn));
		for(int j=n;j>=1;j--)
		{
			for(int t=1;t<=m;t++) minn[t]=min(minn[t],pos[t][a[i][j]]);
			for(int t=1;t<=m;t++) dp[0][a[i][j]][t]=min(dp[0][a[i][j]][t],minn[t]);
		}
	}
	
	for(int k=1;k<18;k++) for(int i=1;i<=n;i++) for(int t=1;t<=m;t++) for(int mid=1;mid<=m;mid++)
		dp[k][i][t]=min(dp[k][i][t],dp[k-1][a[mid][dp[k-1][i][mid]]][t]);
/*	for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=n;j++) cout<<dp[1][j][i]<<" ";
		puts("");
	}*/
	int q;
	scanf("%d",&q);
	while(q--)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		int ans=0,flg=0;
		for(int i=1;i<=m;i++) 
		{
			minn[i]=pos[i][x];
			if(pos[i][x]<pos[i][y]) 
			{
				puts("1"),flg=1;
				break;
			}
		}
		if(flg) continue;
		for(int k=17;k>=0;k--) 
		{
			memset(minn2,0x3f,sizeof(minn2));
			for(int i=1;i<=m;i++) for(int j=1;j<=m;j++) 
				minn2[i]=min(minn2[i],dp[k][a[j][minn[j]]][i]);
			bool Flg=0;
		//	cout<<"... "<<k<<endl;
		//	for(int i=1;i<=m;i++) cout<<minn2[i]<<" ";
		//	puts("");
			for(int i=1;i<=m;i++) if(minn2[i]<=pos[i][y])
			{
				Flg=1;
				break;
			}
			if(Flg) continue;
			ans+=(1<<k);
		//	cout<<k<<endl;
			for(int i=1;i<=m;i++) minn[i]=minn2[i];//,cout<<minn[i]<<" ";
		//	puts("");
		//	system("pause");
		}		
		if(ans>n) ans=-3;
		printf("%d\n",ans+2);
	}
}
signed main()
{
	freopen("6-3.in","r",stdin);
	freopen("6-3.ans","w",stdout);
	int _=1;
//	cin>>_;
	while(_--) solve();
	return 0;
}

/*
Things to notice:
1. do not calculate useless values
2. do not use similar names
 
Things to check:
1. submit the correct file
2. time (it is log^2 or log)
3. memory
4. prove your naive thoughts 
5. long long
6. corner case like n=0,1,inf or n=m
7. check if there is a mistake in the ds or other tools you use
8. fileio in some oi-contest

9. module on time 
10. the number of a same divisor in a math problem
11. multi-information and queries for dp and ds problems
*/
#include<bits/stdc++.h>
using namespace std;
#define fi first
#define se second
#define pii pair<int,int>
#define mp make_pair
#define pb push_back
const int mod=998244353;
const int inf=0x3f3f3f3f;
int n,M;
char g[1505][1505];
int R[1505][1505],D[1505][1505],U[1505][1505],L[1505][1505];
int maxR[1505],maxD[1505],maxU[1505],maxL[1505];
void solve()
{
	cin>>n;
	M=2;
	for(int i=1;i<=n;i++) cin>>(g[i]+1);
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) if(g[i][j]=='.')
	{
		int l=j;
		while(l+1<=n&&g[i][j]==g[i][l+1]) l++;
		for(int x=j;x<=l;x++) R[i][x]=l-x+1,L[i][x]=x-j+1;
		j=l;
	}
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) if(g[j][i]=='.')
	{
		int l=j;
		while(l+1<=n&&g[j][i]==g[l+1][i]) l++;
		for(int x=j;x<=l;x++) D[x][i]=l-x+1,U[x][i]=x-j+1;
		j=l;
	}
	for(int i=1;i<=n;i++) 
	{
		maxL[i]=maxL[i-1];
		for(int j=1;j<=n;j++) maxL[i]=max(maxL[i],max(L[j][i],D[j][i]));
		maxU[i]=maxU[i-1];
		for(int j=1;j<=n;j++) maxU[i]=max(maxU[i],max(L[i][j],U[i][j]));
	}
	for(int i=n;i>=1;i--)
	{
		maxR[i]=maxR[i+1];
		for(int j=1;j<=n;j++) maxR[i]=max(maxR[i],max(R[j][i],D[j][i]));
		maxD[i]=maxD[i+1];
		for(int j=1;j<=n;j++) maxD[i]=max(maxD[i],max(R[i][j],D[i][j]));
	}
//	for(int i=1;i<=n;i++) cout<<maxU[i]<<" ";
//	cout<<"\n";
//	for(int i=1;i<=n;i++) cout<<maxD[i]<<" ";
//	cout<<"\n";
	if(M==1)
	{
		cout<<maxL[n]<<"\n";
		return;
	}
	int l=1,r=n,res=0;
	while(l<=r)
	{
		int mid=(l+r)>>1;
		int ok=0;
		for(int x=1;x<=n;x++) for(int y=1;y<=n;y++) if(R[y][x]>=mid&&max(max(maxL[x-1],maxR[x+mid]),max(maxU[y-1],maxD[y+1]))>=mid) ok=1;//,cout<<mid<<" "<<x<<" "<<y<<"\n";
		for(int x=1;x<=n;x++) for(int y=1;y<=n;y++) if(D[y][x]>=mid&&max(max(maxL[x-1],maxR[x+1]),max(maxU[y-1],maxD[y+mid]))>=mid) ok=1;//,cout<<mid<<" "<<x<<" "<<y<<"\n";
		if(ok) res=mid,l=mid+1;
		else r=mid-1;
	}
	cout<<res<<"\n";
}
signed main()
{
	freopen("2-3.in","r",stdin);
	freopen("2-3.ans","w",stdout);
//	ios::sync_with_stdio(0);
//	cin.tie(0);
	int _=1;
//	cin>>_;
	while(_--) solve();
	return 0;
}
